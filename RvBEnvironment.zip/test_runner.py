import os
import multiprocessing as mp
import logging
import time

import tensorflow as tf

from RvBSimulation import RvBSimulation
from RvBLearner import RvBLearner, SmallRvBLearner, MediumRvBLearner
from Memory import BasicMemory

os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.get_logger().setLevel('WARNING')
tf.autograph.set_verbosity(1)
tf.get_logger().setLevel(logging.ERROR)


def run_one(parent_dir):
    print(parent_dir)
    start_load = time.time()
    memory = BasicMemory(memory_size=1)
    p1_learner = MediumRvBLearner(num_joint_actions=9)
    p2_learner = MediumRvBLearner(num_joint_actions=9)
    p1_learner.load_model(f'{parent_dir}/ddg_model')
    p2_learner.load_model(f'{parent_dir}/sag_model')
    config_file = './configs/phase2-config.ini'
    simulator = RvBSimulation(memory, p1_learner, p2_learner, 3, epsilon=0.99, epsilon_decay=0.9999, config_file=config_file)
    end_load = time.time()

    start_sim = time.time()
    local_history = []
    ddg_safe = 0
    sag_safe = 0
    all_safe = 0
    for i in range(100):
        test_reward, test_number_of_steps = simulator.run_game_iteration(use_epsilon_greedy=False,
                                                                         render_video=False,
                                                                         learn=False)
        local_history.append(test_reward)
        if simulator.previous_ddg_safe:
            ddg_safe += 1
            if simulator.previous_sag_safe:
                all_safe += 1

        if simulator.previous_sag_safe:
            sag_safe += 1

    end_sim = time.time()

    average = sum(local_history) / len(local_history)
    print(parent_dir, average, ddg_safe, sag_safe, all_safe, end_load - start_load, end_sim - start_sim)
    return average, ddg_safe, sag_safe, ddg_safe


if __name__ == '__main__':

    rewards = []
    steps = []

    rewards = [-32.62, 10.69, -46.77, 35.78, 19.69, 47.89, 3.94, -54.02, 78.32, 17.77, -16.61, 144.56, -42.04, 121.52,
               174.52, 105.21, 272.3, 190.46, 276.56, -21.02, -50.13, -63.2, 180.32, 123.68, 249.96, 317.53, -51.91,
               -9.96, -45.6, 197.32, 55.11, 146.88, 274.42, 299.61, 351.61, 443.24, 452.49, 363.52, 408.06, 387.26,
               219.76, 442.91, 353.51, 590.97, 491.2, 147.44, 100.16, 90.75, 176.47, 321.53, 97.56, 293.68, 572.3,
               220.42, 501.4, 673.03, 496.16, 342.49, 524.2, 126.56, 436.94, 478.69, 531.27, 212.75, 375.2, 335.91,
               334.35, 540.98, 655.73, 635.06, 598.3, 283.9, 544.98, 382.02, 423.78, 234.62, 501.75, 499.34, 186.54,
               643.55, 338.87, 691.23, 543.22, 497.06, 462.77, 473.78, 790.13, 366.73, 235.48, 175.22, 685.21, 818.67,
               655.12, 628.51, 710.03, 771.36, 737.45, 769.32, 901.05, 740.08, 841.83, 850.89, 794.17, 795.54, 677.7,
               704.49, 805.1, 617.6, 667.85, 651.99, 794.16, 657.6, 942.06, 852.85, 781.37, 789.76, 844.4, 711.64,
               841.47, 795.58, 799.65, 856.74, 923.55, 947.56, 913.89, 790.5, 834.59, 845.99, 999.87, 992.65, 801.04,
               949.52, 915.14, 821.68, 887.98, 964.13, 813.35, 810.14, 933.06, 1007.75, 958.68, 547.7, 818.46, 879.77,
               604.47, 838.48, 608.32, 716.61, 935.9, 891.3, 657.63, 958.38, 680.35, 920.15, 621.56, 806.51, 844.28,
               1021.66, 813.74, 836.75, 946.27, 771.5, 860.76, 899.88, 845.68, 759.8, 746.86, 829.68, 920.83, 898.61,
               777.63, 883.1, 837.91, 879.93, 881.63, 895.6, 848.74, 811.3, 900.93, 824.35, 822.14, 720.95, 718.02,
               879.13, 650.36, 857.66, 878.17, 760.73, 811.19, 739.0, 783.63, 813.46, 855.16, 876.52, 794.43, 930.99,
               802.13, 945.26, 925.28, 914.59, 787.25, 937.36, 778.88, 830.71, 941.72, 827.33, 866.38, 874.01]
    steps = [500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500, 7000, 7500, 8000, 8500, 9000,
             9500, 10000, 10500, 11000, 11500, 12000, 12500, 13000, 13500, 14000, 14500, 15000, 15500, 16000, 16500,
             17000, 17500, 18000, 18500, 19000, 19500, 20000, 20500, 21000, 21500, 22000, 22500, 23000, 23500, 24000,
             24500, 25000, 25500, 26000, 26500, 27000, 27500, 28000, 28500, 29000, 29500, 30000, 30500, 31000, 31500,
             32000, 32500, 33000, 33500, 34000, 34500, 35000, 35500, 36000, 36500, 37000, 37500, 38000, 38500, 39000,
             39500, 40000, 40500, 41000, 41500, 42000, 42500, 43000, 43500, 44000, 44500, 45000, 45500, 46000, 46500,
             47000, 47500, 48000, 48500, 49000, 49500, 50000, 50500, 51000, 51500, 52000, 52500, 53000, 53500, 54000,
             54500, 55000, 55500, 56000, 56500, 57000, 57500, 58000, 58500, 59000, 59500, 60000, 60500, 61000, 61500,
             62000, 62500, 63000, 63500, 64000, 64500, 65000, 65500, 66000, 66500, 67000, 67500, 68000, 68500, 69000,
             69500, 70000, 70500, 71000, 71500, 72000, 72500, 73000, 73500, 74000, 74500, 75500, 76000, 76500, 77000,
             77500, 78000, 78500, 79000, 79500, 80000, 80500, 81000, 81500, 82000, 83000, 83500, 84000, 84500, 85000,
             85500, 86000, 86500, 87000, 87500, 88000, 88500, 89000, 89500, 90000, 90500, 91000, 91500, 92000, 92500,
             93000, 93500, 94000, 94500, 95000, 95500, 96000, 96500, 97000, 97500, 98000, 98500, 99000, 99500, 100000,
             100500, 101000, 101500, 102000, 102500, 103000, 103500, 104000, 104500, 105000]

    model_dir = './models'
    # model_dir = 'D:/workspaces/work/RvBPhase2/experiments/2.4/models'
    start_model = 500

    model = start_model
    model_dirs = []
    while os.path.exists(f'{model_dir}/{model}'):
        current_model_dir = f'{model_dir}/{model}'
        if model not in steps:
            # avg = run_one(current_model_dir)
            # rewards.append(avg)
            # steps.append(model)
            # print(model, avg)
            # print(rewards)
            # print(steps)
            print('adding', model)
            model_dirs.append(current_model_dir)
        model += 500

    pool = mp.Pool(mp.cpu_count() // 2)
    results = pool.map(run_one, model_dirs)
    pool.close()

    print('final')
    print(results)
