
epsilon = 0.99
epsilon_decay = 0.99999

count = 0
while epsilon > 0.1:
    count += 1
    epsilon *= epsilon_decay

print(count, epsilon)